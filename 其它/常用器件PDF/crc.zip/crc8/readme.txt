Date: Wed, 05 Feb 1997 19:13:54 GMT
From: John Wren <jcwren@atlanta.com>
To: 8051code@keil.com
Subject: 8 Bit CCITT-8 CRC Calculator, Table And/Or Calculation Driven
 
        Here's a CCITT-8 CRC calculator.  The source contains both the
calculated (smaller but slower) version, and the table driven (faster
but larger) version.
 
                - John
 
John C. Wren, KD4DTS
jcwren@atlanta.com
770-840-9200 x2417 (W)

Date: Wed, 05 Feb 1997 19:35:12 GMT
From: John Wren <jcwren@atlanta.com>
To: 8051code@keil.com
Subject: 16 Bit CCITT-16 CRC Calculator, Table And/Or Calculation Driven
 
        Here's a CCITT-16 CRC calculator.  The source contains both
the calculated (smaller but slower) version, and the table driven
(faster but larger) version.
 
                - John
 
John C. Wren, KD4DTS
jcwren@atlanta.com
770-840-9200 x2417 (W)

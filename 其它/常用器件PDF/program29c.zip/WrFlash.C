/*---------------------------------------------------------------*/

void WrFlash( BYTE far *TargetAddr, BYTE far *SourceAddr, WORD Len )
{
	WORD	i;

	while(Len>256)
	{
		*(FlashSite+0x5555)=0xAA;
		*(FlashSite+0x2AAA)=0x55;
		*(FlashSite+0x5555)=0xA0;
		for(i=0;i<256;i++)
		{
			*TargetAddr++=*SourceAddr++;
		}
		delayms(10);
		Len=Len-256;
	}
	*(FlashSite+0x5555)=0xAA;
	*(FlashSite+0x2AAA)=0x55;
	*(FlashSite+0x5555)=0xA0;
	for(i=0;i<Len;i++)
	{
		*TargetAddr++=*SourceAddr++;
	}
	delayms(10);
}

/*---------------------------------------------------------------*/

void delayms( BYTE ticks )
{
	WORD	Count;
	BYTE	Tick;
	for (Tick=ticks;Tick>0;Tick--)
	{
		for (Count=0;Count<=2000;Count++);
	}
}

/*---------------------------------------------------------------*/